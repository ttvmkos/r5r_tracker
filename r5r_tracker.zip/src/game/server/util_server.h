﻿//===== Copyright � 1996-2005, Valve Corporation, All rights reserved. ======//
//
// Purpose: 
//
//===========================================================================//
#ifndef UTIL_SERVER_H
#define UTIL_SERVER_H
#include "game/server/player.h"

CPlayer* UTIL_PlayerByIndex(int nIndex);

#endif // UTIL_SERVER_H
