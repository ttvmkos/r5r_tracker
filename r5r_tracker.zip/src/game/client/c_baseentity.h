#ifndef C_BASEENTITY_H
#define C_BASEENTITY_H

// How many data slots to use when in multiplayer.
#define MULTIPLAYER_BACKUP 750

#endif // C_BASEENTITY_H
