#ifndef LOADER_H
#define LOADER_H

__declspec(dllexport) void DummyExport()
{
	// Required for detours.
}

#endif // LOADER_H
