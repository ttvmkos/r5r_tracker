#ifndef IINPUT_H
#define IINPUT_H

abstract_class IInput
{
public:
	virtual ~IInput() {};
};

#endif // IINPUT_H
