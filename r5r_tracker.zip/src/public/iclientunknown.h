#ifndef ICLIENTUNKNOWN_H
#define ICLIENTUNKNOWN_H

class IClientUnknown
{
	void* __vftable /*VFT*/;
};


#endif // ICLIENTUNKNOWN_H