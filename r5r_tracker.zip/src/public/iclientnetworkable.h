#ifndef ICLIENTNETWORKABLE_H
#define ICLIENTNETWORKABLE_H

class IClientNetworkable
{
public:
	void* __vftable /*VFT*/;
	//virtual ~IClientNetworkable(void) = 0;
	// !TODO!
};

#endif // ICLIENTNETWORKABLE_H