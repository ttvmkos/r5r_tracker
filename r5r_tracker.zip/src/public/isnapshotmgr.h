#ifndef ISNAPSHOTMGR_H
#define ISNAPSHOTMGR_H

abstract_class IClientSnapshotManager
{
public:
	virtual ~IClientSnapshotManager(void) = 0;
};

#endif // ISNAPSHOTMGR_H