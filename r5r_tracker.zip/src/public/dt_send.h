#pragma once

class SendTable
{
public:
	// TODO
};