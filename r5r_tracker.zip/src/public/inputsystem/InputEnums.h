//===========================================================================//
//
// Purpose: 
//
//===========================================================================//
#ifndef INPUTENUMS_H
#define INPUTENUMS_H

struct InputEvent_t
{
	const char* m_pCommand;
	int m_nTick;
	bool m_bDown;
};

#endif // INPUTENUMS_H
