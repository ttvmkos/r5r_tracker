#ifndef ICLIENTTHINKABLE_H
#define ICLIENTTHINKABLE_H

class IClientThinkable
{
	void* __vftable /*VFT*/;
};

#endif // ICLIENTTHINKABLE_H