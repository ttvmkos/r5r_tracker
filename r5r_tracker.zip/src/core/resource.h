//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by r5dev.rc
//
#define IDB_PNG1                        101
#define IDB_PNG2                        102
#define IDB_PNG3                        103
#define IDB_PNG4                        104
#define IDB_PNG5                        105
#define IDB_PNG6                        106
#define IDB_PNG7                        107
#define IDB_PNG8                        108
#define IDB_PNG9                        109
#define IDB_PNG10                       110
#define IDB_PNG11                       111
#define IDB_PNG12                       112
#define IDB_PNG13                       113
#define IDB_PNG14                       114
#define IDB_PNG15                       115
#define IDB_PNG16                       116
#define IDB_PNG17                       117
#define IDB_PNG18                       118
#define IDB_PNG19                       119
#define IDB_PNG20                       120
#define IDB_PNG21                       121
#define IDB_PNG22                       122
#define IDB_PNG23                       123
#define IDB_PNG24                       124
#define IDB_PNG25                       125
#define IDB_PNG26                       126
#define IDB_PNG27                       127
#define IDB_PNG28                       128
#define IDB_PNG29                       129
#define IDB_PNG30                       130
#define IDB_PNG31                       131
#define IDB_PNG32                       132
#define DEV                             256
#define PNG                             256

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        119
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
