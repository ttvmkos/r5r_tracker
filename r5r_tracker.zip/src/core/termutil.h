#pragma once
extern const char* g_svGreyF;
extern const char* g_svRedF;
extern const char* g_svGreenF;
extern const char* g_svBlueF;
extern const char* g_svYellowF;

extern const char* g_svGreyB;
extern const char* g_svRedB;
extern const char* g_svGreenB;
extern const char* g_svBlueB;
extern const char* g_svYellowB;

extern const char* g_svReset;

void AnsiColors_Init();
