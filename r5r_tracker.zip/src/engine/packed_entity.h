#if !defined( PACKED_ENTITY_H )
#define PACKED_ENTITY_H

struct PackedEntity
{
	_DWORD field_0;
	_QWORD field_8;
};

#endif // PACKED_ENTITY_H