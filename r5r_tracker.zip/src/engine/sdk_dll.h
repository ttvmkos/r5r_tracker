#ifndef SDK_DLL_H
#define SDK_DLL_H

class CEngineSDK
{
public:
	void FixedFrame();
};

extern CEngineSDK* g_EngineSDK;

#endif // SDK_DLL_H
